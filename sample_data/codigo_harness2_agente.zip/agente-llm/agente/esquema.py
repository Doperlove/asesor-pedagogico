"""Esquema de la acción propuesta por el modelo."""
from dataclasses import dataclass

ACCIONES = {"listar_archivos", "leer_resumen", "mover_archivo", "terminar"}


@dataclass
class Accion:
    herramienta: str
    argumento: str
    razon: str


def validar_accion(datos: dict) -> Accion:
    """Valida la salida JSON del modelo antes de ejecutarla."""
    if datos.get("herramienta") not in ACCIONES:
        raise ValueError(f"Herramienta no permitida: {datos.get('herramienta')}")
    if not isinstance(datos.get("argumento"), str):
        raise ValueError("argumento debe ser texto")
    return Accion(datos["herramienta"], datos["argumento"], datos.get("razon", ""))
