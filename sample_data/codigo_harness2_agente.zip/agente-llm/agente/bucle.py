"""Bucle ReAct con supervisión humana."""
import json

from .esquema import validar_accion


def ejecutar(modelo, herramientas, aprobar, max_pasos=10):
    """modelo(historial)->str JSON; herramientas: dict nombre->función; aprobar(accion)->bool."""
    historial = []
    for paso in range(max_pasos):
        bruto = modelo(historial)
        try:
            accion = validar_accion(json.loads(bruto))
        except (ValueError, json.JSONDecodeError) as exc:
            historial.append({"paso": paso, "error": str(exc)})
            continue
        if accion.herramienta == "terminar":
            return historial
        if accion.herramienta == "mover_archivo" and not aprobar(accion):
            historial.append({"paso": paso, "rechazada": accion.argumento})
            continue
        resultado = herramientas[accion.herramienta](accion.argumento)
        historial.append({"paso": paso, "accion": accion.herramienta, "resultado": resultado})
    return historial
