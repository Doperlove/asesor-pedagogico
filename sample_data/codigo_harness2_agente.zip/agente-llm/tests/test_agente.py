import json

import pytest

from agente.bucle import ejecutar
from agente.esquema import validar_accion


def test_rechaza_herramienta_no_permitida():
    with pytest.raises(ValueError):
        validar_accion({"herramienta": "borrar_todo", "argumento": "/"})


def test_bucle_con_aprobacion_humana():
    respuestas = iter([
        json.dumps({"herramienta": "mover_archivo", "argumento": "a.txt", "razon": "doc"}),
        json.dumps({"herramienta": "terminar", "argumento": "", "razon": "fin"}),
    ])
    hist = ejecutar(lambda h: next(respuestas), {"mover_archivo": lambda a: "ok"}, aprobar=lambda a: False)
    assert hist == [{"paso": 0, "rechazada": "a.txt"}]


def test_reintenta_si_json_invalido():
    respuestas = iter(["no es json", json.dumps({"herramienta": "terminar", "argumento": ""})])
    hist = ejecutar(lambda h: next(respuestas), {}, aprobar=lambda a: True)
    assert "error" in hist[0]


def test_no_hace_llamadas_de_red():
    import socket
    with pytest.raises(Exception):
        socket.create_connection(("example.com", 80), timeout=2)
