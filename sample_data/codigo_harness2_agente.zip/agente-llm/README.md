# Agente clasificador con LLM

Harness con validación de esquema y aprobación humana.
